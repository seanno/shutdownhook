nohup java \
  -cp dss-server-1.0-SNAPSHOT.jar \
  com.shutdownhook.dss.server.App \
  config.json &
