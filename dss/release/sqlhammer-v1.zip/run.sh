nohup java \
  -cp dss-server-1.0-SNAPSHOT-jar-with-dependencies.jar \
  com.shutdownhook.dss.server.App \
  config.json &
